using System.Windows.Controls;

namespace MemoryGame.Views
{
    public partial class GameView : UserControl
    {
        public GameView()
        {
            InitializeComponent();
        }
    }
}
