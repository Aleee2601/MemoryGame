using System.Windows.Controls;

namespace MemoryGame.Views
{
    public partial class StatisticsView : UserControl
    {
        public StatisticsView()
        {
            InitializeComponent();
        }
    }
}
